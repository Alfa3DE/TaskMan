﻿using Zatsip9000.TaskPlanner.Domain.Models;

namespace Zatsepin9000.TaskPlanner.DataAccess.Abstractions
{
    public class DataAccessAbstractionsClass
    {

    }
}
